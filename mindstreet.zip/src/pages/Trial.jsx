import React from 'react'
import { useEffect } from 'react'

const Trial = () => {
    let totalTime = 4

    function runAnimation(totalTime) {
        console.log('asdf')

        let interval = setInterval(() => {



            console.log("pos")
        }, 25)

        setTimeout(() => {
            clearInterval(interval)
        }, totalTime * 1000)

    }

    useEffect(() => {
        runAnimation(totalTime)
    }, [])

    // runAnimation(totalTime)
    return (
        <div>Trial</div>
    )
}

export default Trial