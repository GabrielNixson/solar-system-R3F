import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Provider } from 'rxdb-hooks';
import HomePage from "./pages/HomePage";
import Trial from "./pages/Trial";

import './App.css';

function App() {

  return (
    <Provider>
      <Router>
          <Routes>
            <Route exact path='/' element={ <HomePage /> } />
            <Route exact path='/trial' element={ <Trial /> } />
            <Route exact path='*' element={<HomePage />} />
          </Routes>
        </Router>
    </Provider>
  );
}

export default App;
